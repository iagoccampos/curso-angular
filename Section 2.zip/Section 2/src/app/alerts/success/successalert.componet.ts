import { Component } from '@angular/core'

@Component({
    selector: 'app-success-alert',
    templateUrl: './successalert.component.html'
})
export class SuccessAlertComponent {

}