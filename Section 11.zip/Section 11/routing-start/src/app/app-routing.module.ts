import { HomeComponent } from "./home/home.component";
import { UsersComponent } from "./users/users.component";
import { Routes, Router, RouterModule } from "@angular/router";
import { UserComponent } from "./users/user/user.component";
import { ServersComponent } from "./servers/servers.component";
import { ServerComponent } from "./servers/server/server.component";
import { EditServerComponent } from "./servers/edit-server/edit-server.component";
import { NgModule } from "@angular/core";
import { AuthGuard } from "./auth-guard.service";
import { CanDeactivateGuard } from "./servers/edit-server/can-deactivate-guard.service";
import { ErrorPageComponent } from "./error-page/error-page.component";
import { ServerResolver } from "./servers/server/server-resolver.service";

const appRoutes: Routes = [
    { path: '', component: HomeComponent },
    {
        path: 'users', component: UsersComponent, children: [
            { path: ':id/:name', component: UserComponent }
        ]
    },
    {
        path: 'servers', canActivateChild: [AuthGuard], component: ServersComponent, children: [ //Agora precisa <router-outlet>
            { path: ':id', component: ServerComponent, resolve: { server: ServerResolver } },
            { path: ':id/edit', canDeactivate: [CanDeactivateGuard], component: EditServerComponent }
        ]
    },
    { path: 'pageNotFound', component: ErrorPageComponent, data: { message: 'Page not found!' } },
    { path: '**', redirectTo: '/pageNotFound' }
];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes, { useHash: true })],
    exports: [RouterModule]
})
export class AppRountingModule {

}