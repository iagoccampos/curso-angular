export class AuthService {
    private loggedIn = true

    isAuthenticated() {
        return new Promise<boolean>((resolve, reject) => {
            setTimeout(() => {
                resolve(this.loggedIn)
            }, 800);
        })
    }

    loggin() {
        this.loggedIn = true
    }

    loggout() {
        this.loggedIn = false
    }
}