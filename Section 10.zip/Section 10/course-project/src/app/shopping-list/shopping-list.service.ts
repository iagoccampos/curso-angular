import { Ingredient } from '../shared/ingredients.model';
import { EventEmitter } from '@angular/core';

export class ShoppingListService {
    onIngredientAdded = new EventEmitter<Ingredient[]>()

    private ingredients: Ingredient[] = []

    getIngredients(): Ingredient[] {
        return this.ingredients.slice()
    }

    addIngredient(ingredient: Ingredient) {
        this.ingredients.push(ingredient)
        this.onIngredientAdded.emit(this.ingredients.slice())
    }

    addMultipleIngredients(ingredients: Ingredient[]) {
        this.ingredients.push(...ingredients)
        this.onIngredientAdded.emit(this.ingredients.slice())
    }
}