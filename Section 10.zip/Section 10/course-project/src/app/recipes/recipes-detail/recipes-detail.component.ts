import { Component, Input } from '@angular/core';
import { Recipe } from '../recipes-list/recipe-item/recipe-item.model';
import { ShoppingListService } from 'src/app/shopping-list/shopping-list.service';

@Component({
  selector: 'app-recipes-detail',
  templateUrl: './recipes-detail.component.html',
  styleUrls: ['./recipes-detail.component.css']
})
export class RecipesDetailComponent {
  @Input() recipe: Recipe

  constructor(private slService: ShoppingListService) { }

  addIngredients(): void {
    this.slService.addMultipleIngredients(this.recipe.ingredients)
  }
}
