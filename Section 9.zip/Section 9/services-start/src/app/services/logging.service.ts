export class LogginService {
    logStatusChange(status: string) {
        console.log('Status: ' + status)
    }
}