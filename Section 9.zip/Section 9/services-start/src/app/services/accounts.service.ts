import { Account } from "../account/account.model";
import { Injectable } from "@angular/core";
import { LogginService } from "./logging.service";

@Injectable() //Pode ser injetado algo nele
export class AccountsService {
    accounts: Account[] = [
        {
            name: 'Master Account',
            status: 'active'
        },
        {
            name: 'Testaccount',
            status: 'inactive'
        },
        {
            name: 'Hidden Account',
            status: 'unknown'
        }
    ];

    constructor(private logginService: LogginService) { }

    addAccount(newAccount: Account) {
        this.accounts.push(newAccount);
        this.logginService.logStatusChange(newAccount.status)
    }

    updateStatus(updateInfo: { id: number, newStatus: string }) {
        this.accounts[updateInfo.id].status = updateInfo.newStatus;
        this.logginService.logStatusChange(updateInfo.newStatus)
    }
}