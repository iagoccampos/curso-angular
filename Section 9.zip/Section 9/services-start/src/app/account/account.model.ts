export interface Account {
    id?: number
    name: string
    status: string
}