import { Component, Input } from '@angular/core';
import { AccountsService } from '../services/accounts.service';
import { Account } from './account.model';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css'],
})
export class AccountComponent {
  @Input() account: Account;
  @Input() id: number;

  constructor(private accountsService: AccountsService) { }

  onSetTo(status: string) {
    this.accountsService.updateStatus({ id: this.id, newStatus: status })
  }
}
